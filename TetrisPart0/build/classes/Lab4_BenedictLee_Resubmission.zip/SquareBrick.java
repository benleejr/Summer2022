
public class SquareBrick extends TetrisBrick {

    public SquareBrick() {

    }

    public void initPosition() {

    }
}
