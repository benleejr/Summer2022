public class JayBrick extends TetrisBrick {

    public JayBrick() {

    }

    public void initPosition() {

    }
}