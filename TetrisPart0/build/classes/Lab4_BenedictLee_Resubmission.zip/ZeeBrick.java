public class ZeeBrick extends TetrisBrick {

    public ZeeBrick() {

    }

    public void initPosition() {

    }
}