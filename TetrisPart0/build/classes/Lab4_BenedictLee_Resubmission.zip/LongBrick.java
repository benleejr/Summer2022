/*
 * MouseClick listener and mouse adapter to override the listener anonymously
 * Challenge what to change to make it a two player game
 * 
 */
/**
 *
 * @author Hales
 */
public class LongBrick extends TetrisBrick {

    public LongBrick() {

    }

    public void initPosition() {

    }
}