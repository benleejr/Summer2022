public class StackBrick extends TetrisBrick {

    public StackBrick() {

    }

    public void initPosition() {

    }
}