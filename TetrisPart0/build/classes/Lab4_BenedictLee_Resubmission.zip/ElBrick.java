public class ElBrick extends TetrisBrick {

    public ElBrick() {

    }

    public void initPosition() {

    }
}