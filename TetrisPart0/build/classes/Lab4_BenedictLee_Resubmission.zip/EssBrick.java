public class EssBrick extends TetrisBrick {

    public EssBrick() {

    }

    public void initPosition() {

    }
}